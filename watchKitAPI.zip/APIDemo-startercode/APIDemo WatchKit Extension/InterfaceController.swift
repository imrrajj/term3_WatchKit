//

//  InterfaceController.swift

//  APIDemo WatchKit Extension

//

//  Created by Parrot on 2019-03-03.

//  Copyright © 2019 Parrot. All rights reserved.

//



import WatchKit

import Foundation

import Alamofire

import SwiftyJSON



class InterfaceController: WKInterfaceController {
    
  
    
    @IBOutlet var lblSunrise: WKInterfaceLabel!
    
    @IBOutlet var lblSunset: WKInterfaceLabel!
    
    @IBOutlet var lblCity: WKInterfaceLabel!
    
    
    override func awake(withContext context: Any?) {
        
        super.awake(withContext: context)
        
        
        
        // Configure interface objects here.
        
    }
    
    
    
    override func willActivate() {
        
        // This method is called when watch view controller is about to be visible to user
        
        super.willActivate()
        
        let URL =
            
        "https://api.sunrise-sunset.org/json?lat=49.2827&lng=-123.1207&date=today"
        
        Alamofire.request(URL).responseJSON {
            
            // 1. store the data from the internet in the
            
            // response variable
            
            response in
            
            // 2. get the data out of the variable
            
            guard let apiData = response.result.value else {
                
                print("Error getting data from the URL")
                
                return
                
            }
            
            // OUTPUT the entire json response to the terminal
            
            print(apiData)
            
            // GET sunrise/sunset time out of the JSON response
            
            let jsonResponse = JSON(apiData)
            
            let sunriseTime = jsonResponse["results"]["sunrise"].string
            
            let sunsetTime = jsonResponse["results"]["sunset"].string
            
            // DEBUG: Output it to the terminal
            
            //            print("Sunrise: \(sunriseTime)")
            
            //            print("Sunset: \(sunsetTime)")
            
            // display in a UI
            
            self.lblSunrise.setText("Sunrise: \(sunriseTime!)")
            
            self.lblSunset.setText("Sunset: \(sunsetTime!)")        // TODO: Put your API call here
            
        }
        
    }
    
    override func didDeactivate() {
        
        // This method is called when watch view controller is no longer visible
        
        super.didDeactivate()
        
    }
    
    
    
}

