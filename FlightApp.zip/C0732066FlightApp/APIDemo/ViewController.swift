//
//  ViewController.swift
//  APIDemo
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON           // import this to process your JSON response

class ViewController: UIViewController {

    // MARK: Outlets
    @IBOutlet weak var edtFrom: UITextField!
    @IBOutlet weak var edtTo: UITextField!
    @IBOutlet weak var edtDate: UITextField!
    @IBOutlet weak var edtAdult: UITextField!
    @IBOutlet weak var edtSeat: UITextField!
    let API_ID = "85a80be8"
    let API_KEY = "65470d15fd086f1aa9e3498dc1715d4e"
    
    @IBAction func btnShw(_ sender: Any) {
        
        var from : String = edtFrom.text!
        var to : String = edtTo.text!
        var date : String = edtDate.text!
        var adult : String = edtAdult.text!
        var seat : String = edtSeat.text!
        
         print("**************BEFORE****************")
       
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        print("**************BEFORE****************")
        
        
        let URL = "https://developer.goibibo.com/api/search/?app_id=85a80be8&app_key=65470d15fd086f1aa9e3498dc1715d4e&format=json&source=YYZ&destination=YUL&dateofdeparture=20190313&seatingclass=E&adults=1&children=0&infants=0&counter=0"
        
        Alamofire.request(URL).responseJSON {
            // 1. store the data from the internet in the
            // response variable
            response in
            
            // 2. get the data out of the variable
            guard let apiData = response.result.value else {
                print("Error getting data from the URL")
                return
            }
            
            // OUTPUT the json response to the terminal
            print(apiData)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

