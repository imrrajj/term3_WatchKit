//
//  InterfaceController.swift
//  APIDemo WatchKit Extension
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import Alamofire
import SwiftyJSON

class InterfaceController: WKInterfaceController {

    
    @IBOutlet var lblDepDate: WKInterfaceLabel!
    @IBOutlet var lblArrDate: WKInterfaceLabel!
    @IBOutlet var lblClass: WKInterfaceLabel!
    // MARK: Outlets
    @IBOutlet var sunriseTimeLabel: WKInterfaceLabel!
    @IBOutlet var sunsetTimeLabel: WKInterfaceLabel!
    
    @IBOutlet var lblWarning: WKInterfaceLabel!
    @IBOutlet var lblTime: WKInterfaceLabel!
    @IBOutlet var loadingImage: WKInterfaceImage!
    @IBOutlet var lblFare: WKInterfaceLabel!
    @IBOutlet var lblDeptTime: WKInterfaceLabel!
    
    @IBOutlet var lblArrTime: WKInterfaceLabel!
    
    @IBOutlet var toCity: WKInterfaceLabel!
    @IBOutlet var cityNameLabel: WKInterfaceLabel!
  
    @IBAction func btnBook() {
        
    }
    let sharedPreferences = UserDefaults.standard
    // MARK: Default functions
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let flightno = context as? String{
             self.sunriseTimeLabel.setText(flightno)
            self.sunsetTimeLabel.setText(sharedPreferences.string(forKey: "air"))
            self.lblTime.setText(sharedPreferences.string(forKey: "dur"))
            self.lblFare.setText(sharedPreferences.string(forKey: "fare"))
            self.lblArrTime.setText(sharedPreferences.string(forKey: "arr"))
            self.lblDeptTime.setText(sharedPreferences.string(forKey: "deptime"))
            self.lblClass.setText(sharedPreferences.string(forKey: "class"))
            self.lblArrDate.setText(sharedPreferences.string(forKey: "arrdate"))
            self.lblDepDate.setText(sharedPreferences.string(forKey: "depdate"))
            self.lblWarning.setText("* \(sharedPreferences.string(forKey: "war")!)")
            
            
//            var air = sharedPreferences.string(forKey: "air")
//            var fare = sharedPreferences.string(forKey: "fare")
//            var depdate = sharedPreferences.string(forKey: "depdate")
//            var arrdate = sharedPreferences.string(forKey: "arrdate")
//            
        }
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        // 1. when the app starts, show the loading animation
        // 2. go get data from website
        // 3. when you get the data,
        //       -stop the animation (hide the animation)
        //       - update the labels with sunrise/sunset data
        
        
        // 0. Check if there is a previously saved city
       
        var city = sharedPreferences.string(forKey: "city")
        var toCity = sharedPreferences.string(forKey: "toCity")

//        if (city == nil && toCity == nil) {
//            // by default, the strating city is Vancouver
//            city = "YYZ"
//            toCity = "YUL"
//            print("No city was set, setting default city to Vancouver")
//        }
//        else {
//            print("\(city!) ----------- \(toCity!)")
//        }
//
//        // update the label to show the current city
        self.cityNameLabel.setText(city)
        self.toCity.setText(toCity)
//
//
//
//        // 1. start the animation
//        self.loadingImage.setImageNamed("Progress")
//        self.loadingImage.startAnimatingWithImages(in: NSMakeRange(0, 10), duration: 2, repeatCount: 0)
//
//        // 2. UPDATE THE LABELS SO USER KNOWS TEH DATA IS LOADING
//        self.sunriseTimeLabel.setText("Updating...")
//        self.sunsetTimeLabel.setText("Updating...")
//        self.lblDeptTime.setText("Updating...")
//        self.lblArrTime.setText("Updating...")
//        self.lblTime.setText("Updating...")
//
//
//        // ---------------
//
//        let URL = "https://developer.goibibo.com/api/search/?app_id=85a80be8&app_key=65470d15fd086f1aa9e3498dc1715d4e&format=json&source=\(city!)&destination=\(toCity!)&dateofdeparture=20190330&seatingclass=E&adults=1&children=0&infants=0&counter=0"
//
//
//        Alamofire.request(URL).responseJSON {
//            // 1. store the data from the internet in the
//            // response variable
//            response in
//
//            // 2. get the data out of the variable
//            guard let apiData = response.result.value else {
//                print("Error getting data from the URL")
//                return
//            }
//
//            // GET something out of the JSON response
//            let jsonResponse = JSON(apiData)
//
//         //   let fare = jsonResponse["data"]["onwardflights"][0]["fare"]["totalfare"].string!
//
//
//            // stop the animation
//            self.loadingImage.stopAnimating()
//            // and then hide it
//            self.loadingImage.setImageNamed(nil)
//
//            // show the sunrise and sunset in the IPhone App
//            self.sunriseTimeLabel.setText(jsonResponse["data"]["onwardflights"][0]["flightno"].string!)
//            self.sunsetTimeLabel.setText(jsonResponse["data"]["onwardflights"][0]["airline"].string!)
//            self.lblTime.setText(jsonResponse["data"]["onwardflights"][0]["duration"].string!)
//            //self.lblFare.setText(jsonResponse["data"]["onwardflights"][0]["fare"]["totalfare"].string!)
//            self.lblDeptTime.setText(jsonResponse["data"]["onwardflights"][0]["depdate"].string!)
//            self.lblArrTime.setText(jsonResponse["data"]["onwardflights"][0]["arrdate"].string!)
//
 //
 //       }
        
        // ---------------
    }
   
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
