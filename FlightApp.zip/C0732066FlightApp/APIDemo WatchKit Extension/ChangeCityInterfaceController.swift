//
//  ChangeCityInterfaceController.swift
//  APIDemo
//
//  Created by MacStudent on 2019-03-05.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation


class ChangeCityInterfaceController: WKInterfaceController {

    // MARK: Outlet
    // MARK: Variable names
    var cityName:String?
    var toCity:String?
    var pass:String?
 let sharedPreferences = UserDefaults.standard
   
    @IBOutlet var btnTo: WKInterfaceButton!
    @IBOutlet var btnFrom: WKInterfaceButton!
    // MARK: Actions
    @IBAction func saveCityButtonPressed() {
      
    }

    @IBAction func btnToPick() {
        let suggestedResponses = ["YYZ", "YUL", "AMD", "DEL"]

        presentTextInputController(withSuggestions: suggestedResponses, allowedInputMode: .plain) {

            (results) in

            if (results != nil && results!.count > 0) {
                // 2. write your code to process the person's response
                let userResponse = results?.first as? String
                // 3. also save the user's choice to the cityName variable
                self.toCity = userResponse
                self.btnTo.setTitle(userResponse)
                
               
                self.sharedPreferences.set(self.cityName, forKey:"city")
                self.sharedPreferences.set(self.toCity, forKey: "toCity")
                print("Saved \(self.cityName!) to shared preferences!")
                print("Saved \(self.toCity!) to shared preferences!")
                
            }
        }


    }

    @IBAction func pickCityButtonPressed() {
        // add the code to let user do input!!

        // 1. When person clicks on button, show them the input UI
        let suggestedResponses = ["YYZ", "YUL", "AMD", "DEL"]

        presentTextInputController(withSuggestions: suggestedResponses, allowedInputMode: .plain) {

            (results) in

            if (results != nil && results!.count > 0) {
                // 2. write your code to process the person's response
                let userResponse = results?.first as? String
                self.btnFrom.setTitle(userResponse)
                // 3. also save the user's choice to the cityName variable
                self.cityName = userResponse
            }
        }


    }
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
//        var date: [WKPickerItem] = []
//        for i in 1...31 {
//            // 2
//            let item = WKPickerItem()
//            item.title = String(i)
//            date.append(item)
//        }
//        // 3
//        datePicker.setItems(date)
//
//        var month: [WKPickerItem] = []
//        for i in 1...12 {
//            // 2
//            let item = WKPickerItem()
//            item.title = String(i)
//            month.append(item)
//        }
//        // 3
//        monthPicker.setItems(month)
//
//        var year: [WKPickerItem] = []
//        for i in 2019...2020 {
//            // 2
//            let item = WKPickerItem()
//            item.title = String(i)
//            year.append(item)
//        }
//        // 3
//        yearPicker.setItems(year)
//
//        print("Date : \(date) Month : \(month) Year : \(year)")
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        print("I loaded page 2")
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
