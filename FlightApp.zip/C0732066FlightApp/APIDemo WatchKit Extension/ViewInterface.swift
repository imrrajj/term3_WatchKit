//
//  ViewInterface.swift
//  APIDemo WatchKit Extension
//
//  Created by raj mistry on 2019-03-25.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation


class ViewInterface: WKInterfaceController {
  let sharedPreferences = UserDefaults.standard
    @IBOutlet var lblAir: WKInterfaceLabel!
    @IBOutlet var lblF: WKInterfaceLabel!
    @IBOutlet var lblD: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        self.lblAir.setText(sharedPreferences.string(forKey: "air"))
        self.lblF.setText(sharedPreferences.string(forKey: "fare"))
        self.lblD.setText(sharedPreferences.string(forKey: "deptime"))
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
