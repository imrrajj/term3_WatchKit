//
//  TabelDataInterface.swift
//  APIDemo WatchKit Extension
//
//  Created by raj mistry on 2019-03-23.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import Alamofire
import SwiftyJSON


class TabelDataInterface: WKInterfaceController {

    @IBOutlet var lblLoad: WKInterfaceLabel!
    @IBOutlet var lblFrom: WKInterfaceLabel!
    @IBOutlet var lblTo: WKInterfaceLabel!
    var json = JSON()
    var dept : String?
    var air : String?
     let sharedPreferences = UserDefaults.standard
    @IBOutlet var tableRow: WKInterfaceTable!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        //loadData()
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
       
        var city = sharedPreferences.string(forKey: "city")
        var toCity = sharedPreferences.string(forKey: "toCity")
        //var pass = sharedPreferences.string(forKey: "pass")
        if (city == nil && toCity == nil) {
            // by default, the strating city is Vancouver
            city = "YYZ"
            toCity = "YUL"
            print("No city was set, setting default city to Vancouver")
        }
        else {
            print("\(city!) ----------- \(toCity!)")
        }
        self.lblLoad.setText("Searching Flight...")
        self.lblFrom.setText(city!)
        self.lblTo.setText(toCity!)
     
        let URL = "https://developer.goibibo.com/api/search/?app_id=85a80be8&app_key=65470d15fd086f1aa9e3498dc1715d4e&format=json&source=\(city!)&destination=\(toCity!)&dateofdeparture=20190330&seatingclass=E&adults=1&children=0&infants=0&counter=0"
        
        
        Alamofire.request(URL).responseJSON {
            // 1. store the data from the internet in the
            // response variable
            response in
            
            // 2. get the data out of the variable
            guard let apiData = response.result.value else {
                print("Error getting data from the URL")
                return
            }
            
            // GET something out of the JSON response
            //let jsonResponse = JSON(apiData)
            self.json = JSON(apiData)
            //   let fare = jsonResponse["data"]["onwardflights"][0]["fare"]["totalfare"].string!
            self.loadData()
            
        }
        
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    private func loadData(){
        self.lblLoad.setText("Search Completed")
        tableRow.setNumberOfRows(json["data"]["onwardflights"].count, withRowType: "RowController")
        
        //for(index, rowModel) in json.enumerated(){
             for var i in 0..<json["data"]["onwardflights"].count{
            if let rowController = tableRow.rowController(at: i) as? RowController{
                rowController.lblAirline.setText(json["data"]["onwardflights"][i]["airline"].string!)
                rowController.lblPrice.setText(json["data"]["onwardflights"][i]["duration"].string!)
                rowController.lblDuration.setText("Seat : \(json["data"]["onwardflights"][i]["seatsavailable"].string!)")
               // rowController.lblPrice.setText(json["data"]["onwardflights"][i]["fare"]["totalfare"].rawValue as! String)
            }
            
        }
        
    }
    
    
    
    override func table(_ table: WKInterfaceTable, didSelectRowAt rowIndex: Int) {
        
        var f = json["data"]["onwardflights"][rowIndex]["fare"]["totalfare"].rawValue
        print("\(f)")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["airline"].string!, forKey: "air")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["duration"].string!, forKey: "dur")
        sharedPreferences.set(f, forKey: "fare")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["deptime"].string!, forKey: "deptime")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["arrtime"].string!, forKey: "arr")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["warnings"].string!, forKey: "war")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["depdate"].string!, forKey: "depdate")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["arrdate"].string!, forKey: "arrdate")
        sharedPreferences.set(json["data"]["onwardflights"][rowIndex]["seatingclass"].string!, forKey: "class")
        //var arr = ["dept","air"]
        
        pushController(withName: "detailInterface", context: json["data"]["onwardflights"][rowIndex]["flightno"].string!)
    }
    
}
