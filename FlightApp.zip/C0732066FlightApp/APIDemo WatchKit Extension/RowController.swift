//
//  RowController.swift
//  APIDemo WatchKit Extension
//
//  Created by raj mistry on 2019-03-23.
//  Copyright © 2019 Parrot. All rights reserved.
//

import Foundation
import WatchKit

class RowController : NSObject{
    
    @IBOutlet var lblAirline: WKInterfaceLabel!
    @IBOutlet var lblDuration: WKInterfaceLabel!
    @IBOutlet var lblPrice: WKInterfaceLabel!
}
